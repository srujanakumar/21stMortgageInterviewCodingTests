import { Injectable } from '@angular/core';
import { IloginResult } from '../interfaces/ilogin-result';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  getLoginResult(username: string, password: string): Promise<IloginResult> {
    let response: IloginResult = { loginSucessful: false };
    if(username && password){
      response.loginSucessful = true;
    }
    return new Promise((resolve, reject) => { resolve(response) });
  }
}
