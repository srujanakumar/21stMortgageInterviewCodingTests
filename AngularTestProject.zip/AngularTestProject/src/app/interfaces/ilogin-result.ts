export interface IloginResult {
    loginSucessful: boolean
}
