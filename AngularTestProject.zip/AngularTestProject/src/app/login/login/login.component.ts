import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;
  public submitted = false;
  public loginResult = "";

  constructor(private formBuilder: FormBuilder, private router: Router, private loginService: LoginService) {}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.email, Validators.required]],
      password: [
        "",
        [
          Validators.required
        ]
      ]
    });
  }

  get formControl() {
    return this.loginForm.controls;
  }

  onLogin(): void {
    // console.log(this.loginForm.value);
    this.submitted = true;
    if (this.loginForm.valid) {
      
      this.loginService.getLoginResult(this.loginForm.value["email"], this.loginForm.value["password"])
        .then(response => {
          this.submitted = false;
          this.loginForm.reset();
          this.loginResult = response.loginSucessful ? "Login sucessful" : "login failed";
        },
        error => {
          console.log(error);
          this.submitted = false;
          this.loginResult = "login failed";
        }).catch(e => console.log(e));
    }
  }

}
