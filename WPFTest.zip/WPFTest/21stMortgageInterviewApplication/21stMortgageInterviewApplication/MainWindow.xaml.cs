﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21stMortgageInterviewApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void cmd_LargestNum_Click(object sender, RoutedEventArgs e)
        {
            if (tb_UserInput.Text != null)
            {
                int[] integers = getIntegersArray(tb_UserInput.Text);

                if(integers.Count()!=0)
                {
                    tb_Result.Text = integers.Max().ToString();
                    if (Convert.ToInt32(tb_Result.Text) >= 0)
                    {
                        tb_Result.Background = Brushes.Green;
                    }
                    else
                    {
                        tb_Result.Background = Brushes.Red;
                    }

                }

            }

        }

        private int[] getIntegersArray(string UserInput)
        {
            string[] numbers = UserInput.Split(',');
            int[] integers = new int[numbers.Length];
            int i = 0;
            foreach (string s in numbers)
            {
                int number;
                if (!int.TryParse(s.Trim(), out number))
                {
                    MessageBox.Show("Input must be a list of integers, separated by commas");
                    return new int[0];
                }
                else
                {
                    integers[i] = Convert.ToInt32(s.Trim());
                }
                i++;
            }
            return integers;

        }

        private void cmd_EvenSum_Click(object sender, RoutedEventArgs e)
        {
            if (tb_UserInput.Text != null)
            {
                int[] integers = getIntegersArray(tb_UserInput.Text);

                
                if (integers.Count() != 0)
                {

                    tb_Result.Text = getEvenNumbersSum(integers).ToString();
                    if(Convert.ToInt32(tb_Result.Text)>=0)
                    {
                        tb_Result.Background = Brushes.Green;
                    }
                    else
                    {
                        tb_Result.Background = Brushes.Red;
                    }
                }
            }
        }

        private int getEvenNumbersSum(int[] numbers)
        {
            int[] even = new int[numbers.Length];
            int j = 0;
            int evensum=0;
            for(int i=0;i<numbers.Length;i++)
            {
                if(numbers[i]%2==0)
                {
                    even[j] = numbers[i];
                    j++;
                }
            }

            for(int k=0;k<j;k++)
            {
                evensum = evensum + even[k];
            }
            return evensum;
        }

        private int getOddNumbersSum(int[] numbers)
        {
            int[] odd = new int[numbers.Length];
            int j = 0;
            int oddsum = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] % 2 != 0)
                {
                    odd[j] = numbers[i];
                    j++;
                }
            }

            for (int k = 0; k < j; k++)
            {
                oddsum = oddsum + odd[k];
            }
            return oddsum;
        }

        private void cmd_OddSum_Click(object sender, RoutedEventArgs e)
        {
            if (tb_UserInput.Text != null)
            {
                int[] integers = getIntegersArray(tb_UserInput.Text);


                if (integers.Count() != 0)
                {

                    tb_Result.Text = getOddNumbersSum(integers).ToString();
                    if (Convert.ToInt32(tb_Result.Text) >= 0)
                    {
                        tb_Result.Background = Brushes.Green;
                    }
                    else
                    {
                        tb_Result.Background = Brushes.Red;
                    }

                }
            }
        }

    }
}
