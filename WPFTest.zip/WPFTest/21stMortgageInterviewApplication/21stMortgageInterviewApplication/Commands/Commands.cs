﻿

namespace _21stMortgageInterviewApplication.Commands
{
    using System;
    using System.Windows.Input;
    using _21stMortgageInterviewApplication.ViewModel;
    internal class CommandActions : ICommand
    {
        private InputViewModel _inputviewmodel;

        private string commandname = "";
        public string CommandName
        {
            get { return commandname; }
            set
            {
                if (commandname != value)
                {
                    commandname = value;
                }
            }
        }
        public CommandActions(InputViewModel inputviewmodel,string _CommandName)
        {
            _inputviewmodel = inputviewmodel;
            CommandName = _CommandName;
        }

        public event EventHandler CanExecuteChanged {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return _inputviewmodel.canUpdate;
        }

        public void Execute(object parameter)
        {
            if (CommandName == "LargestNumberClicked")
            {
                _inputviewmodel.FindLargestNum();
            }
            else if (CommandName == "SumOfEvenClicked")
            {
                _inputviewmodel.getEvenNumbersSum();

            }
            else if (CommandName == "SumOfOddClicked")
            {
                _inputviewmodel.getOddNumbersSum();
            }
        }
    }
}
