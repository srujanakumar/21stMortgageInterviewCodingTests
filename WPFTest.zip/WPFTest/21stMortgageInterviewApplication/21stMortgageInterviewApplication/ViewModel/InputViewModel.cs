﻿using _21stMortgageInterviewApplication.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Diagnostics;

namespace _21stMortgageInterviewApplication.ViewModel
{
    class InputViewModel :INotifyPropertyChanged
    {
        public InputViewModel()
        {
            LargestNumberClicked = new CommandActions(this, "LargestNumberClicked");
            SumOfEvenClicked = new CommandActions(this, "SumOfEvenClicked");
            SumOfOddClicked = new CommandActions(this, "SumOfOddClicked");
        }

        private string userInput = "";
        public string UserInput
        {
            get { return userInput; }
            set
            {
                if (userInput != value)
                {
                    userInput = value;
                    OnPropertyChanged("UserInput");
                }
            }
        }

        private Brush result_color;

        public Brush Result_color
        {
            get { return result_color; }
            set
            {
                result_color = value;
                OnPropertyChanged("Result_color");
            }
        }

        private string result;
        public string Result
        {
            get
            {
                return result;
            }
            set
            {
                result = value;
                OnPropertyChanged("Result");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public ICommand LargestNumberClicked
        {
            get;
            private set;
        }

        public ICommand SumOfEvenClicked
        {
            get;
            private set;
        }

        public ICommand SumOfOddClicked
        {
            get;
            private set;
        }

        public void FindLargestNum()
        {
            if (UserInput != null)
            {
                int[] integers = getIntegersArray(UserInput);

                if (integers.Count() != 0)
                {
                    Result = integers.Max().ToString();
                    if (Convert.ToInt32(Result) >= 0)
                    {
                        Result_color = Brushes.Green;
                    }
                    else
                    {
                        Result_color = Brushes.Red;
                    }
                }

            }
        }

        public void getEvenNumbersSum()
        {
            if (UserInput != null)
            {
                int[] integers = getIntegersArray(UserInput);
                if (integers.Count() != 0)
                {
                    int[] even = new int[integers.Length];
                    int j = 0;
                    int evensum = 0;
                    for (int i = 0; i < integers.Length; i++)
                    {
                        if (integers[i] % 2 == 0)
                        {
                            even[j] = integers[i];
                            j++;
                        }
                    }

                    for (int k = 0; k < j; k++)
                    {
                        evensum = evensum + even[k];
                    }
                    Result= evensum.ToString();
                    if (Convert.ToInt32(Result) >= 0)
                    {
                        Result_color = Brushes.Green;
                    }
                    else
                    {
                        Result_color = Brushes.Red;
                    }
                }
            }

        }

        public void getOddNumbersSum()
        {
            if (UserInput != null)
            {
                int[] integers = getIntegersArray(UserInput);
                if (integers.Count() != 0)
                {
                    int[] odd = new int[integers.Length];
                    int j = 0;
                    int oddsum = 0;
                    for (int i = 0; i < integers.Length; i++)
                    {
                        if (integers[i] % 2 != 0)
                        {
                            odd[j] = integers[i];
                            j++;
                        }
                    }

                    for (int k = 0; k < j; k++)
                    {
                        oddsum = oddsum + odd[k];
                    }
                    Result= oddsum.ToString();
                }
            }
        }

        private int[] getIntegersArray(string UserInput)
        {
            string[] numbers = UserInput.Split(',');
            int[] integers = new int[numbers.Length];
            int i = 0;
            foreach (string s in numbers)
            {
                int number;
                if (!int.TryParse(s.Trim(), out number))
                {
                    MessageBox.Show("Input must be a list of integers, separated by commas");
                    return new int[0];
                }
                else
                {
                    integers[i] = Convert.ToInt32(s.Trim());
                }
                i++;
            }
            return integers;

        }

        public bool canUpdate
        {
            get
            {
                if(String.IsNullOrWhiteSpace(UserInput))
                {
                    return false;
                }
                return !String.IsNullOrWhiteSpace(UserInput);
            }
        }


    }
}

